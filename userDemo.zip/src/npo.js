export class Npo {
    constructor(name, rating, description){
        this.name = name;
        this.rating = rating;
        this.description = description;
    }
}