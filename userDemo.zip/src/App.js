import './App.css';
import { UserDash } from './userDash'

function App() {
  return (
    <div className="App">
      <UserDash />
    </div>
  );
}

export default App;
